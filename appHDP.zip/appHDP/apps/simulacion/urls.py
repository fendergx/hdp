from django.conf.urls import url, include

from apps.simulacion.views import index

urlpatterns = [
    url(r'^$', index),
]