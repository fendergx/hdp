from django.apps import AppConfig


class SimulacionConfig(AppConfig):
    name = 'simulacion'
