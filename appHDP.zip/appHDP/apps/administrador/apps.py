from django.apps import AppConfig


class AdministradorConfig(AppConfig):
    name = 'administrador'
