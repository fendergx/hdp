from django.conf.urls import url

from apps.administrador.views import index
urlpatterns = [
  url(r'^$', index)
]